require('dotenv').config()
;(async () => {
  const fs = require('fs')
  const database = require('./database')

  const dbFiles = fs.readdirSync(__dirname + '/migrate')

  for (const file of dbFiles) {
    const lines = fs
      .readFileSync(__dirname + '/migrate/' + file, 'utf-8')
      .replace(
        'id|username|name_user|balance|balance_diamonds|is_blacklisted',
        ''
      )
      .split('\n')

    const users = lines
      .map((line) => {
        const parts = line.split('|')
        return {
          name: parts?.[2] ?? null,
          userId: Number(parts?.[0] || String(0)),
          credits: parseFloat(parts?.[3]) || 0.0,
          restrict: Boolean(Number(parts?.[5]) || false),
        }
      })
      .filter((user) => user.userId)

    for (const userInfo of users) {
      const userExists = await database.User.exists({
        id: userInfo.userId,
      })

      console.log(userInfo)

      if (userExists) continue

      const user = new database.User({
        id: userInfo.userId,
        name: userInfo.name || `User ${userInfo.userId}`,
        credits: userInfo.credits,
        historic: [],
        current_transactions: 0,
        restrict: userInfo.restrict,
        admin: false,
        shopping: {
          credits: 0,
          cards: 0,
          gifts: 0,
        },
        in_purchase: false,
      })

      await user.save()
    }
    process.exit(1)
  }
})()
