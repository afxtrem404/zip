exports.inlineSearch = async (inline_data, database, bot) => {
  const DataBaseFunctions = require('../class')
  const [action, ...term] = inline_data.query.split(' ')
  const DBF = new DataBaseFunctions(database, inline_data)
  const autorizacao = await DBF.user().admin()
  const search = term.join(' ')
  const Store = await database.Store.findOne({
    name: process.env.STORE_NAME,
  })

  if (action.toLowerCase() == 'usuario') {
    if (autorizacao.success) {
      const users = await database.User.find({
        $or: [
          {
            name: { $regex: search },
          },
          /^\d+$/.test(search)
            ? { id: parseInt(search) }
            : {
                name: {
                  $regex: search,
                },
              },
        ],
      }).limit(49)

      const usersAnswerQuery = users?.length
        ? users.map((user) => {
            return {
              type: 'article',
              id: user.id,
              title: user.name,
              description: `Id: ${user.id}`,
              input_message_content: {
                message_text:
                  `<b>Nome:</b> <code>${user.name.replace(
                    /(<([^>]+)>)/gi,
                    ''
                  )}</code>\n` +
                  `<b>Id: </b><code>${user.id}</code>\n` +
                  `<b>Conta restrita: </b><code>${
                    user.restrict ? 'sim' : 'não'
                  } </code>\n` +
                  `<b>Admin: </b><code>${
                    user.admin ? 'sim' : 'não'
                  } </code>\n` +
                  `<b>Saldo: </b><code>R$${user.credits}</code>\n` +
                  `<b>Cartões: </b><code>${user.shopping.cards}</code>\n` +
                  `<b>Gifts: </b><code>${user.shopping.gifts}</code>`,
                parse_mode: 'html',
              },
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: '✏️ Editar usuário',
                      callback_data: 'editarUsuario',
                    },
                  ],
                  [
                    {
                      text: '🗑 Deletar usuário',
                      callback_data: 'deletarUsuario',
                    },
                  ],
                ],
              },
            }
          })
        : [
            {
              type: 'article',
              id: 'not found',
              title: 'Usuário não encontrado',
              input_message_content: {
                message_text:
                  `<b>Termo: </b><code>${search}</code>\n` +
                  `<b>Resultado</b>: <i>Não encontrado</i>`,
                parse_mode: 'html',
              },
            },
          ]

      console.log(usersAnswerQuery)
      bot.answerInlineQuery(inline_data.id, usersAnswerQuery, {
        cache_time: 1000,
      })
    } else {
      bot.answerInlineQuery(
        inline_data.id,
        [
          {
            type: 'article',
            id: 'not found',
            title: 'Acesso não autorizado.',
            input_message_content: {
              message_text: `????`,
              parse_mode: 'html',
            },
          },
        ],
        { cache_time: 1000 }
      )
    }
  } else {
    async function QueryAction(type) {
      let searchType

      const callback =
        type == 'bin'
          ? ((searchType = 'bin'),
            (card) => card.bin.bin.includes(search))
          : type == 'banco'
          ? ((searchType = 'banco'),
            (card) =>
              card.bin.bank
                ? card.bin.bank.name.toLowerCase().includes(search)
                : 'NÃO ESPECIFICADO'.includes(search))
          : type == 'bandeira'
          ? ((searchType = 'bandeira'),
            (card) => card.bin.scheme.toLowerCase().includes(search))
          : 0

      const cardsWithFilter = await database.Cards.find({
        restrict: false,
      }).populate('level')

      const totalCards = cardsWithFilter.filter(callback)
      const cards = totalCards.slice(0, 47)

      const cardsAnswerQuery = cards?.length
        ? cards.map((card) => {
            return {
              type: 'article',
              id: card.number,
              title: `${card.number
                .slice(0, 6)
                .padEnd(card.number.toString().length, '*')} ${
                card.month
              }/${card.year}`,
              description: `Cartão ${card.level.type}, ${
                card.bin.scheme
              }, ${
                card.bin.bank
                  ? card.bin.bank.name
                  : 'Banco desconhecido'
              } de R$${card.level.price}`,
              input_message_content: {
                message_text:
                  `<b>Cartão:</b> <i>${card.number
                    .slice(0, 6)
                    .padEnd(
                      card.number.toString().length,
                      '*'
                    )}</i>\n` +
                  `<b>Banco:</b> <i>${
                    card.bin.bank
                      ? card.bin.bank.name
                      : 'Não especificado'
                  }</i>\n` +
                  `<b>Tipo:</b> <i>${
                    card.bin.type ? card.bin.type : 'Não especificado'
                  }</i>\n` +
                  `<b>Valor: </b><i>${
                    card.level.price == 'A combinar'
                      ? card.level.price
                      : `R$${card.level.price}`
                  }</i>`,
                parse_mode: 'html',
              },
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: '✅ Comprar',
                      callback_data: `comprarCartao_${card.number}`,
                    },
                  ],
                  [
                    {
                      text: '❌ Cancelar',
                      callback_data: 'cancelarCompra',
                    },
                  ],
                ],
              },
            }
          })
        : [
            {
              type: 'article',
              id: 'not found',
              title: searchType + ' não encontrada(o)',
              input_message_content: {
                message_text:
                  `<b>${searchType}: </b><code>${search}</code>\n` +
                  `<b>Resultado</b>: <i>Não encontrado(a)</i>`,
                parse_mode: 'html',
              },
            },
          ]

      cardsAnswerQuery.length > 0 &&
      cardsAnswerQuery[0].id != 'not found'
        ? cardsAnswerQuery.unshift(
            {
              type: 'article',
              id: 'founds',
              title: `Cartões encontrados: ${cards.length}/${totalCards.length}`,
              input_message_content: {
                message_text:
                  `<b>${searchType}: </b><code>${search}</code>\n` +
                  `<b>Resultados</b>: <i>${cardsAnswerQuery.length}</i>`,
                parse_mode: 'html',
              },
            }
            /* {
              type: 'article',
              id: 'warn',
              title: `Aviso ⚠️`,
              description: `Compras por este meio, não terão trocas, não efetuamos reembolso/troca nenhuma. Material ja vai testado no ato da compra!`,
              input_message_content: {
                message_text:
                  `<b>Aviso ⚠️</b>` +
                  `<b>Compras por inline (bin, banco, bandeira), não terão trocas, não efetuamos reembolso/troca nenhuma. Material ja vai testado no ato da compra!</b>`,
                parse_mode: 'html',
              },
            }*/
          )
        : 0

      const userInfo = (await DBF.user().informacoes()).response
      const desclaimer = `Caro cliente, você so pode comprar unitária novamente após sair a cc solicitada anteriormente. ⚠️Aguarde...`

      if (userInfo.in_purchase)
        return await bot.answerInlineQuery(
          inline_data.id,
          [
            {
              type: 'article',
              id: 'not allowed',
              title: `Ação não permitida`,
              description: desclaimer,
              input_message_content: {
                message_text: desclaimer,
                parse_mode: 'html',
              },
            },
          ],
          {
            cache_time: 1,
          }
        )
      else if (Store.test_mode && !autorizacao.success)
        return await bot.answerInlineQuery(
          inline_data.id,
          [
            {
              type: 'article',
              id: 'not allowed',
              title: `Ação não permitida`,
              description: 'Store em manutenção',
              input_message_content: {
                message_text: 'Store em manutenção',
                parse_mode: 'html',
              },
            },
          ],
          {
            cache_time: 1,
          }
        )
      else if (userInfo.restrict)
        return await bot.answerInlineQuery(
          inline_data.id,
          [
            {
              type: 'article',
              id: 'not allowed',
              title: `Ação não permitida`,
              description: 'Usuário restrito.',
              input_message_content: {
                message_text: 'Usuário restrito.',
                parse_mode: 'html',
              },
            },
          ],
          {
            cache_time: 1,
          }
        )

      await bot.answerInlineQuery(inline_data.id, cardsAnswerQuery, {
        cache_time: 1,
      })
    }

    const queryTypes = {
      bin: async () => {
        if (Number.isInteger(parseInt(search))) {
          await QueryAction(action.toLowerCase())
        }
      },
      banco: async () => {
        await QueryAction(action.toLowerCase())
      },
      bandeira: async () => {
        await QueryAction(action.toLowerCase())
      },
    }

    if (queryTypes[action.toLowerCase()]) {
      queryTypes[action.toLowerCase()]()
    }
  }
}
