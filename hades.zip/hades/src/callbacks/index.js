require('../utils/PrototypeFunctions')

class Callback {
  constructor(bot, message, Db = {}) {
    this.bot = bot
    this.message = message
    this.Db = Db
    this.owner = process.env.ONWER_USERNAME
    this.channelUrl = process.env.CHANNEL_USERNAME
    this.groupUrl = process.env.GROUP_USERNAME
  }

  async sendClientsGroupLink() {
    const { response: userInfo } = await this.Db.user().informacoes()
    const customersGroupId = process.env.CUSTOMER_GROUP

    if (userInfo.shopping.cards > 1) return

    const fullYear = new Date().getFullYear()
    const expireDate = new Date(fullYear + 5, 1, 1).getTime()

    const inviteLinkOther = {
      expire_date: expireDate,
      name: `Link de convite para o grupo privado de clientes para o usuário ${userInfo.name}`,
      member_limit: 1,
    }

    const invite = await this.bot
      .createChatInviteLink(customersGroupId, inviteLinkOther)
      .catch((err) => ({ err }))

    if (invite.err)
      return console.log(
        `Ocorreu um erro ao gerar o link de convite para o grupo de clientes. Solictado para: ${userInfo.name}`,
        invite
      )
    else
      console.log(
        `Link de convite do grupo de cliente gerado. Solicitado para: ${userInfo.name}`,
        invite
      )

    await this.bot.sendMessage(
      userInfo.id,
      `<b>Obrigado por comprar conosco 🔝😍\n` +
        `Entre no nosso grupo privado de clientes 🤝</>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: 'Entrar no grupo',
                url: invite.invite_link,
              },
            ],
          ],
        },
      }
    )
    return invite
  }

  start(value) {
    const startOptions = {
      message: `<a href= '${process.env.BOT_BANNER}'>&#8205;</a><b>Olá </b>${this.message.from.first_name}, <b>Seja bem vindo!</b>\n\n<a href='${process.env.DOUBTS_CHANNEL}'>👤 Atendimento/a>`,
      //+ `\n<a href='${this.groupUrl}'>👥 Grupo</a>\n<a href='${this.channelUrl}'>📢 Canal</a>`,
      options: {
        reply_to_message_id: this.message.message_id
          ? this.message.message_id
          : this.message.messsage_id,
        parse_mode: 'html',
        disable_web_preview: true,
        chat_id: this.message.message
          ? this.message.message.chat.id
          : this.message.chat.id,
        message_id: this.message.message
          ? this.message.message.message_id
          : this.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '💳 Comprar',
                callback_data: 'comprar',
              },
              {
                text: '👤 Informações',
                callback_data: 'informacoes',
              },
            ],
            [
              {
                text: '📃 Histórico',
                callback_data: 'compras',
              },
            ],
            [
              {
                text: '💵 Adicionar Saldo',
                callback_data: 'adicionarSaldo',
              },
            ],
            [
              {
                text: '👤 Suporte',
                url: `https://t.me/${process.env.SUPPORT_USERNAME.replace(
                  /[^A-z]/g,
                  ''
                )}`,
              },

              {
                text: '👥 Referências',
                url: process.env.REFERENCE_USERNAME,
              },
            ],
          ],
        },
      },
    }

    return startOptions
  }

  async comprar() {
    const { response: userInfo } = await this.Db.user().informacoes()

    const cardsTotal = await this.Db.card().totalQuantidade()

    const alerts = await this.Db.store().alerts.getAlert()

    const callbackid = this.message.id

    const { checker } = await this.Db.store().settings.getSettings()

    if (!checker)
      this.bot.answerCallbackQuery(callbackid, {
        text: 'Checker indisponível, não efetuem compras no momento!\nCompras com checker off não tem reembolso.',
        show_alert: true,
      })

    var buyOptions = {
      message: `<b>Avisos</b>\n- <i>${
        alerts.checker
      }</i>\n\n<b>Informações</b>\n- <b>Saldo:</b> <i>R$${
        userInfo.credits
      }</i>\n- <b>Cartões:</b> <i>${
        cardsTotal.response < 1
          ? 'Nenhum cartão disponível.'
          : cardsTotal.response
      }</i>\n\n<b>Escolha a opção desejada no menu abaixo.</b>`,
      options: {
        reply_to_message_id: this.message.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    if (cardsTotal.response > 0) {
      buyOptions.options.reply_markup.inline_keyboard.push(
        [
          {
            text: '💳 Unitárias',
            callback_data: 'niveis',
          },
          {
            text: '🎲 Aleátoria',
            callback_data: 'cartaoAleatorio',
          },
        ],
        [
          {
            text: '👤 Full dados',
            callback_data: 'full',
          },
        ],
        [
          {
            text: '🔍 Pesquisar Bin',
            switch_inline_query_current_chat: 'bin 544232',
          },
        ],
        [
          {
            text: '🔍 Pesquisar Bandeira',
            switch_inline_query_current_chat: 'bandeira visa',
          },
        ],
        [
          {
            text: '🔍 Pesquisar Banco',
            switch_inline_query_current_chat: 'banco caixa',
          },
        ],
        [
          {
            text: '🔀 Mix',
            callback_data: 'mixDeCartoes',
          },
        ],
        [
          {
            text: '🔙 Voltar',
            callback_data: 'voltarMenuInicial',
          },
        ]
      )
    } else {
      buyOptions.options.reply_markup.inline_keyboard.push([
        {
          text: '🔙 Voltar',
          callback_data: 'voltarMenuInicial',
        },
      ])
    }

    return buyOptions
  }

  async niveis(full = false) {
    const { response: userInfo } = await this.Db.user().informacoes()

    var niveis = await this.Db.level().niveisDisponiveis()

    if (!niveis.success) {
      return {
        message: `${niveis.response}`,
        options: {
          reply_to_message_id: this.message.message_id,
          chat_id: this.message.message.chat.id,
          parse_mode: 'html',
          message_id: this.message.message.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: '🔙 Voltar',
                  callback_data: 'voltarMenuDeCompra',
                },
              ],
            ],
          },
        },
      }
    }

    const cardList = niveis.response
      .filter((l) =>
        full ? l.type.includes('FULL') : !l.type.includes('FULL')
      )
      .map(
        (l) =>
          `- <b>${
            full
              ? l.type.replace('FULL ', '')
              : l.type.capitalizeFirstLetter()
          }: ${
            l.price == 'A combinar' ? 'A combinar' : `R$${l.price}`
          }</b>`
      )
      .join('\n')

    const inlinekeyBoardFormat = niveis.response
      .filter((l) =>
        full ? l.type.includes('FULL') : !l.type.includes('FULL')
      )
      .map((l) => {
        return {
          text: `${
            full ? l.type.replace('FULL', '') : l.type.toUpperCase()
          } ${
            userInfo.admin ? `(${l.total_cards})` : `- R$${l.price}`
          }`,
          callback_data: `level_${l.type}`,
        }
      })
      .spliter()

    inlinekeyBoardFormat.push([
      {
        text: '🔙 Voltar',
        callback_data: 'voltarMenuDeCompra',
      },
    ])

    const levelOptions = {
      message: `<b>💳 Unitárias</b>\n\n${cardList}\n\n⚠️ <b>Avisos</b>\n- <i>Cartões com o valor <b> A combinar </b>, não tiveram seu valor pré-definido.\n- Garantimos live e não saldo\n- Não trocamos por falta de saldo\n- Troca da cc 10 minutos no bot\n\nQualquer dúvida consulte ${this.owner}.</i>`,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: inlinekeyBoardFormat,
        },
      },
    }
    console.timeEnd('Exibicao de menu')
    return levelOptions
  }

  async informacoes() {
    const {
      from: { first_name: name },
      from: { id: userId },
    } = this.message.message.reply_to_message

    const { response: userInfo } = await this.Db.user().informacoes()

    const infoOptions = {
      message: `<b>👤 Perfil</b>\n- <b>Nome: </b><i>${name}</i>\n- <b>Id: </b><code>${userId}</code>\n\n<b>💰 Carteira</b>\n- <b>Saldo:</b> <i>R$${userInfo.credits}</i>\n- <b>Compras: </b><i>${userInfo.shopping.cards}</i>`,
      options: {
        reply_to_message_id: this.message.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '💵 Adicionar saldo',
                callback_data: 'adicionarSaldo',
              },
              {
                text: '👥 Afiliados',
                callback_data: 'afiliados',
              },
            ],
            [
              {
                text: '⚠️ Encerrar Conta',
                callback_data: 'deletarConta',
              },
            ],
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuInicial',
              },
            ],
          ],
        },
      },
    }

    return infoOptions
  }

  async afiliados() {
    const {
      from: { id: userId },
    } = this.message.message.reply_to_message

    const callbackid = this.message.id

    const { username } = await this.bot.getMe()

    const { success, response: affiliations } =
      await this.Db.user().afiliados()

    if (!success) {
      return await this.bot.answerCallbackQuery(callbackid, {
        text: affiliations,
        show_alert: true,
      })
    }

    const infoOptions = {
      message: `<b>👥 Sistema de afiliados</b>\n\n📌 <b>Divulgue seu link de afiliado e ganhe 1$ em toda recarga do seu indicado!</b>\n\nℹ️ <b>Como funciona?</b>\n\n- <i>Cada indicado seu que recarregar no bot, você ganha ${parseInt(
        process.env.REFERRAL_PERCENT
      )}% do valor que ele recarregou</i>\n\n⚠️ <b>Os valores serão concedidos automaticamente em créditos no bot</b>\n\n📎 <b>Afiliado</b>: <code>${
        affiliations.affiliated
      }</code>\n🖇 <b>Afiliados</b>: <code>${
        affiliations.affiliates.length
      }</code>\n\n🔗 <b>Seu link:</b> <code>https://t.me/${username}?start=${userId}</code>`,
      options: {
        reply_to_message_id: this.message.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '🗣 Compartilhar',
                url: `https://t.me/share/url?url=https://t.me/${username}?start=${userId}&text=${process.env.REFERRAL_TEXT}`,
              },
            ],
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuInformacoes',
              },
            ],
          ],
        },
      },
    }

    return infoOptions
  }

  async compras() {
    const {
      from: { first_name: name },
      from: { id: userId },
    } = this.message.message.reply_to_message

    const { response: userInfo } = await this.Db.user().informacoes()

    const historicOptions = {
      message: `<b>Histórico de transações .</b>\n\n💳 <b>Cartões</b>: <i>${userInfo.shopping.cards}</i>\n\n💰 <b>Saldo</b>: <i>R$${userInfo.shopping.credits}</i>\n\n🎁 <b>Gifts: </b><i>${userInfo.shopping.gifts}</i>\n\n<b>Atenção: </b><i> Os valores presentes nesta sessão, é o total comprado, adicionado e resgatado, respectivamente.\nBaixe seu histórico para obter a lista de todos os cartões adquiridos.</i>`,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '⬇️ Baixar Histórico',
                callback_data: 'baixarHistorico',
              },
            ],
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuInicial',
              },
            ],
          ],
        },
      },
    }

    return historicOptions
  }

  async enviarCartaoRandomicoOuPorNivel(
    level = null,
    random = false
  ) {
    var cards = await this.Db.level().pegarCartoes(level)
    const full = level.includes('FULL')

    var randomCardPerLevelOptions = {
      message: String,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    if (random) {
      const randCard = await this.Db.card().cartaoRandomico()

      if (randCard.success) {
        var card = randCard.response

        let { price = 'A combinar', type } =
          await this.Db.level().nivel(
            card.bin.brand ? card.bin.brand : 'Não especificado'
          )

        var cardMasked = card.number.toString()

        cardMasked = type?.includes?.('MISTERIOSA')
          ? cardMasked
              .slice(-4)
              .padStart(card.number.toString().length, '*')
          : cardMasked
              .slice(0, 6)
              .padEnd(card.number.toString().length, '*')

        randomCardPerLevelOptions.message = `<b>Cartão:</b> <i>${cardMasked}</i>\n<b>Banco:</b> <i>${
          type.includes('MISTERIOSA')
            ? 'MISTERIOSO'
            : card.bin.bank
            ? card.bin.bank.name
            : 'Não especificado'
        }</i>\n<b>Tipo:</b> <i>${
          type.includes('MISTERIOSA')
            ? 'MISTERIOSO'
            : card.bin.type
            ? card.bin.type
            : 'Não especificado'
        }</i>\n<b>Valor: </b><i>${
          price == 'A combinar' ? price : `R$${price}`
        }</i>`

        randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push(
          [
            {
              text: '✅ Comprar',
              callback_data:
                `comprarCartão_${card.number}` +
                (card.full ? '_full' : ''),
            },
          ],
          [
            {
              text: '🔙 Voltar',
              callback_data: full ? 'full' : 'voltarMenuNiveis',
            },
          ]
        )
      } else {
        randomCardPerLevelOptions.message = cards.response

        randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push(
          [
            {
              text: '🔙 Voltar',
              callback_data: full ? 'full' : 'voltarMenuNiveis',
            },
          ]
        )
      }
    }

    if (cards.success && !random) {
      var { price = 'A combinar', type } =
        await this.Db.level().nivel(level)

      var card = cards.response.shuffle()[0]

      var cardMasked = card.number.toString()

      cardMasked = type?.includes?.('MISTERIOSA')
        ? cardMasked
            .slice(-4)
            .padStart(card.number.toString().length, '*')
        : cardMasked
            .slice(0, 6)
            .padEnd(card.number.toString().length, '*')

      randomCardPerLevelOptions.message = `<b>Cartão:</b> <i>${cardMasked}</i>\n<b>Banco:</b> <i>${
        type.includes('MISTERIOSA')
          ? 'MISTERIOSO'
          : card.bin.bank
          ? card.bin.bank.name
          : 'Não especificado'
      }</i>\n<b>Tipo:</b> <i>${
        type.includes('MISTERIOSA')
          ? 'MISTERIOSO'
          : card.bin.type
          ? card.bin.type
          : 'Não especificado'
      }</i>\n<b>Valor: </b><i>${
        price == 'A combinar' ? price : `R$${price}`
      }</i>`

      randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push(
        [
          {
            text: '✅ Comprar',
            callback_data: `comprarCartão_${card.number}`,
          },
        ],
        [
          {
            text: '🔙 Voltar',
            callback_data: 'voltarMenuNiveis',
          },
        ]
      )
    } else if (!random) {
      randomCardPerLevelOptions.message = cards.response

      randomCardPerLevelOptions.options.reply_markup.inline_keyboard.push(
        [
          {
            text: '🔙 Voltar',
            callback_data: 'voltarMenuNiveis',
          },
        ]
      )
    }

    this.bot.editMessageText(
      randomCardPerLevelOptions.message,
      randomCardPerLevelOptions.options
    )

    return randomCardPerLevelOptions
  }

  async comprarCartao(card) {
    const callbackid = this.message.id
    const { response: userInfo } = await this.Db.user().informacoes()
    const { checker: checkerIsActive } =
      await this.Db.store().settings.getSettings()
    const Data = require('../utils/PreferenceFunctions')

    const setInPurchase = (state) =>
      this.Db.user().atualizar({ in_purchase: state })

    const observationMessage = checkerIsActive
      ? `<b>Cartão verificado (Live) ☑️</b>`
      : `<b>Este cartão foi comprado com o checker indisponível ℹ️</b>`

    var buyCardOptions = {
      message: String,
      options: {
        reply_to_message_id: this.message.message.message_id,
        parse_mode: 'html',
        chat_id: this.message.message.chat.id,
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    const swapCard = (cartao) => {
      const swapEmitter = this.bot
      const event = `cancellSwap_${cartao.number}`

      const swapCardTime = setTimeout(() => {
        buyCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '❤️',
                callback_data: 'compraFinalizada',
              },
            ],
          ],
        }
        buyCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
          cartao.number
        }|${cartao.month}|${cartao.year}|${
          cartao.cvv
        }</code>\n<b>Banco:</b> <code>${
          cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
        }</code>\n<b>Nivel: </b><code>${
          cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
        }</code>\n<b>Tipo: </b><code>${
          cartao.bin.type ? cartao.bin.type : 'Não especificado'
        }</code>\n\n${
          fullData.success
            ? fullData.response
            : `<b>Nome: </b><code>${Dados.name}</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
        }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>Esgotado</i>`

        this.bot.editMessageText(
          buyCardOptions.message,
          buyCardOptions.options
        )
      }, Number(process.env.SWAP_CARD_TIME) * 60000)

      swapEmitter.on(event, function (eventData) {
        clearTimeout(swapCardTime)

        swapEmitter.removeListener(event, function (deleteData) {
          console.log('delete emitter successfull')
        })
      })
    }

    const notificarCompra = async (cardPurshased) => {
      const channelId = process.env.CARDS_SOLD_LOG_CHANNEL
      this.bot.sendMessage(
        channelId,
        `<b>Compra efetuada</b>\n\n<b>Usuário: </b><a href='tg://user?id=${
          userInfo.id
        }'>${userInfo.name}</a> - <b>R$${userInfo.credits} (- R$${
          cardPurshased.level.price
        })</b>\n<b>Id:</b><code>${
          userInfo.id
        }</code>\n\n<b>Cartão: </b><code>${cardPurshased.number
          .slice(0, 6)
          .padEnd(
            cardPurshased.number.toString().length,
            '*'
          )}</code>\n<b>Expiração: </b><code>${cardPurshased.month.replace(
          /[0-9]/g,
          '*'
        )}/${cardPurshased.year.replace(
          /[0-9]/g,
          '*'
        )}</code>\n<b>Cvv:</b> <code>${cardPurshased.cvv.replace(
          /[0-9]/g,
          '*'
        )}</code>`,
        { parse_mode: 'HTML' }
      )
    }

    var { response: cartao } = await this.Db.card().cartao(card)

    if (cartao.level.price == 'A combinar')
      return this.bot.answerCallbackQuery(
        callbackid,
        'Cartão disponível apenas para compra manual.',
        { show_alert: true }
      )

    if (userInfo.credits >= cartao.level.price) {
      await setInPurchase(true)
      buyCardOptions.message = `<i>Obtendo cartão...</i>`
      buyCardOptions.options.reply_markup.inline_keyboard = [
        [
          {
            text: '🔄 Verificando',
            callback_data: 'none',
          },
        ],
      ]

      await this.bot.editMessageText(
        buyCardOptions.message,
        buyCardOptions.options
      )

      const check = await this.Db.card().cartao(card, true)

      cartao = check.response

      if (cartao.restrict) {
        buyCardOptions.message = `<i>Cartão restrito. Estamos pegando outro para você, aguarde...</i>`
        buyCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '🔄 Verificando',
                callback_data: 'none',
              },
            ],
          ],
        }

        await this.bot.editMessageText(
          buyCardOptions.message,
          buyCardOptions.options
        )

        var cards = await this.Db.level().pegarCartoes(
          cartao.level.type,
          true
        )

        if (cards.success) {
          let updateUser =
            await this.Db.user().verificarEdeduzirSaldo(
              cartao.level.price
            )

          if (!updateUser.success)
            return this.bot.answerCallbackQuery(callbackid, {
              text: `Saldo insuficiente`,
              show_alert: true,
            })

          var { response: cartao } = await this.Db.card().cartao(
            cards.response[0].number
          )

          var Dados = cartao.full
            ? {
                name: cartao.holderName,
                cpf: cartao.holderCpf,
              }
            : Data.getData()

          var fullData = await Data.getFullData(Dados.cpf)

          console.log('Compra realizada: ', cartao)

          buyCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
            cartao.number
          }|${cartao.month}|${cartao.year}|${
            cartao.cvv
          }</code>\n<b>Banco:</b> <code>${
            cartao.bin.bank
              ? cartao.bin.bank.name
              : 'Não especificado'
          }</code>\n<b>Nivel: </b><code>${
            cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
          }</code>\n<b>Tipo: </b><code>${
            cartao.bin.type ? cartao.bin.type : 'Não especificado'
          }</code>\n\n${
            fullData.success
              ? fullData.response
              : `<b>Nome: </b><code>${Dados.name}</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
          }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>10m</i>`

          buyCardOptions.options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: '🔄 Trocar',
                  callback_data: `trocarCartao_${cartao.number}_${Dados.cpf}`,
                },
              ],
            ],
          }

          await setInPurchase(false)

          let updateCardsAndLevel =
            await this.Db.level().restringirCartao(
              cartao.number,
              userInfo.id
            )
          let anexarDados = await this.Db.level().anexarDados(
            cartao.number,
            Dados
          )
          notificarCompra(cartao)
          //let updateUser = await this.Db.user().verificarEdeduzirSaldo(cartao.level.price)

          await this.bot.editMessageText(
            buyCardOptions.message,
            buyCardOptions.options
          )
          await this.sendClientsGroupLink()

          swapCard(cartao)
        } else {
          await setInPurchase(false)
          buyCardOptions.message = `<b>Estamos sem cartões deste nível no momento.</b>`

          buyCardOptions.options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: '🔙 Menu Inicial',
                  callback_data: 'voltarMenuInicial',
                },
              ],
            ],
          }

          await this.bot.editMessageText(
            buyCardOptions.message,
            buyCardOptions.options
          )
        }
      } else {
        var Dados = cartao.full
          ? { name: cartao.holderName, cpf: cartao.holderCpf }
          : Data.getData()
        var fullData = await Data.getFullData(Dados.cpf)

        let updateUser = await this.Db.user().verificarEdeduzirSaldo(
          cartao.level.price
        )

        if (!updateUser.success)
          return (
            this.bot.answerCallbackQuery(callbackid, {
              text: `Saldo insuficiente`,
              show_alert: true,
            }) && (await setInPurchase(false))
          )

        buyCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
          cartao.number
        }|${cartao.month}|${cartao.year}|${
          cartao.cvv
        }</code>\n<b>Banco: </b><code>${
          cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
        }</code>\n<b>Nivel: </b><code>${
          cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
        }</code>\n<b>Tipo: </b><code>${
          cartao.bin.type ? cartao.bin.type : 'Não especificado'
        }</code>\n\n${
          fullData.success
            ? fullData.response
            : `<b>Nome: </b><code>${Dados.name}</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
        }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>10m</i>`

        buyCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '🔄 Trocar',
                callback_data: `trocarCartao_${cartao.number}_${Dados.cpf}`,
              },
            ],
          ],
        }

        await setInPurchase(false)

        let updateCardsAndLevel =
          await this.Db.level().restringirCartao(card, userInfo.id)
        let anexarDados = await this.Db.level().anexarDados(
          card,
          Dados
        )
        notificarCompra(cartao)
        //let updateUser = await this.Db.user().verificarEdeduzirSaldo(cartao.level.price)

        await this.bot.editMessageText(
          buyCardOptions.message,
          buyCardOptions.options
        )
        await this.sendClientsGroupLink()

        swapCard(cartao)
      }
    } else {
      this.bot.answerCallbackQuery(callbackid, {
        text: `Saldo insuficiente`,
        show_alert: true,
      })
    }
  }

  async trocarCartao(data) {
    const Emitter = require('events')
    const { response: userInfo } = await this.Db.user().informacoes()
    const callbackid = this.message.id
    const Data = require('../utils/PreferenceFunctions')

    var swapCardOptions = {
      message: String,
      options: {
        reply_to_message_id: this.message.message.message_id,
        parse_mode: 'html',
        chat_id: this.message.message.chat.id,
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    const [, card, cpf] = data.split('_')

    const swapEmitter = this.bot
    const event = `cancellSwap_${card}`

    swapEmitter.emit(event, 'cancell')

    const oldFullData = await Data.getFullData(cpf)

    const checkerIsActive = async () => {
      const { checker } = await this.Db.store().settings.getSettings()
      return checker
    }

    const observationMessage = (await checkerIsActive())
      ? `<b>Cartão verificado (Live) ☑️</b>`
      : `<b>Este cartão foi comprado com o checker indisponível ℹ️</b>`

    if (!(await checkerIsActive())) {
      return this.bot.answerCallbackQuery(callbackid, {
        text: `Checker indisponível no momento.`,
        show_alert: true,
      })
    }
    swapCardOptions.message = `<i>Avaliando condições de troca...</i>`
    swapCardOptions.options.reply_markup = {
      inline_keyboard: [
        [
          {
            text: '🔄 Verificando',
            callback_data: 'none',
          },
        ],
      ],
    }

    await this.bot.editMessageText(
      swapCardOptions.message,
      swapCardOptions.options
    )

    let { success: live, response: cartao } =
      await this.Db.card().checar(card, true)

    const { name: nome } = cartao.full
      ? {
          name: cartao.holderName,
        }
      : Data.find(cpf)

    if (!(await checkerIsActive())) {
      swapCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
        cartao.number
      }|${cartao.month}|${cartao.year}|${
        cartao.cvv
      }</code>\n<b>Banco:</b> <code>${
        cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
      }</code>\n<b>Nivel: </b><code>${
        cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
      }</code>\n<b>Tipo: </b><code>${
        cartao.bin.type ? cartao.bin.type : 'Não especificado'
      }</code>\n\n${
        oldFullData.success
          ? oldFullData.response
          : `<b>Nome: </b><code>${nome}</code>\n<b>Cpf: </b><code>${cpf}</code>`
      }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>Não disponível.</i>`
      swapCardOptions.options.reply_markup = {
        inline_keyboard: [
          [
            {
              text: '🔄 Trocar',
              callback_data: `trocarCartao_${cartao.number}_${cpf}`,
            },
          ],
        ],
      }

      this.bot.editMessageText(
        swapCardOptions.message,
        swapCardOptions.options
      )
      return this.bot.answerCallbackQuery(callbackid, {
        text: `Checker indisponível no momento.`,
        show_alert: true,
      })
    }

    if (live) {
      swapCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
        cartao.number
      }|${cartao.month}|${cartao.year}|${
        cartao.cvv
      }</code>\n<b>Banco:</b> <code>${
        cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
      }</code>\n<b>Nivel: </b><code>${
        cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
      }</code>\n<b>Tipo: </b><code>${
        cartao.bin.type ? cartao.bin.type : 'Não especificado'
      }</code>\n\n${
        oldFullData.success
          ? oldFullData.response
          : `<b>Nome: </b><code>${nome}</code>\n<b>Cpf: </b><code>${cpf}</code>`
      }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>Não Aprovada.</i>`
      swapCardOptions.options.reply_markup = {
        inline_keyboard: [
          [
            {
              text: '❤️',
              callback_data: 'compraFinalizada',
            },
          ],
        ],
      }

      return this.bot.editMessageText(
        swapCardOptions.message,
        swapCardOptions.options
      )
    } else {
      swapCardOptions.message = `<i>Realizando troca...</i>`
      swapCardOptions.options.reply_markup = {
        inline_keyboard: [
          [
            {
              text: '🔄 Verificando',
              callback_data: 'none',
            },
          ],
        ],
      }

      await this.bot.editMessageText(
        swapCardOptions.message,
        swapCardOptions.options
      )

      const cards = await this.Db.level().pegarCartoes(
        cartao.level.type,
        true,
        (card) => card.bin.bin == cartao.bin.bin
      )

      if (cards.success) {
        const { response: swapedCard } = await this.Db.card().cartao(
          cards.response[0].number
        )
        var Dados = swapedCard.full
          ? { name: swapedCard.holderName, cpf: swapedCard.holderCpf }
          : Data.getData()
        var fullData = await Data.getFullData(Dados.cpf)

        console.log('troca realizada: ', swapedCard)

        swapCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '❤️',
                callback_data: 'compraFinalizada',
              },
            ],
          ],
        }

        swapCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
          swapedCard.number
        }|${swapedCard.month}|${swapedCard.year}|${
          swapedCard.cvv
        }</code>\n<b>Banco:</b> <code>${
          swapedCard.bin.bank
            ? swapedCard.bin.bank.name
            : 'Não especificado'
        }</code>\n<b>Nivel: </b><code>${
          swapedCard.bin.brand
            ? swapedCard.bin.brand
            : 'Não especificado'
        }</code>\n<b>Tipo: </b><code>${
          swapedCard.bin.type
            ? swapedCard.bin.type
            : 'Não especificado'
        }</code>\n\n${
          fullData.success
            ? fullData.response
            : `<b>Nome: </b><code>${Dados.name}</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
        }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>Finalizado.</i>`

        await this.Db.level().restringirCartao(
          swapedCard.number,
          userInfo.id
        )
        await this.bot.editMessageText(
          swapCardOptions.message,
          swapCardOptions.options
        )
      } else {
        swapCardOptions.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<b>Cartão: </b><code>${
          cartao.number
        }|${cartao.month}|${cartao.year}|${
          cartao.cvv
        }</code>\n<b>Banco:</b> <code>${
          cartao.bin.bank ? cartao.bin.bank.name : 'Não especificado'
        }</code>\n<b>Nivel: </b><code>${
          cartao.bin.brand ? cartao.bin.brand : 'Não especificado'
        }</code>\n<b>Tipo: </b><code>${
          cartao.bin.type ? cartao.bin.type : 'Não especificado'
        }</code>\n\n${
          oldFullData.success
            ? oldFullData.response
            : `<b>Nome: </b><code>${nome}</code>\n<b>Cpf: </b><code>${cpf}</code>`
        }\n\n${observationMessage}\n\n⏱ <b>Prazo de troca</b>: <i>Não Disponível.</i>`
        swapCardOptions.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '❤️',
                callback_data: 'compraFinalizada',
              },
            ],
          ],
        }

        await this.Db.user().adicionarSaldo(cartao.level.price)

        return this.bot.editMessageText(
          swapCardOptions.message,
          swapCardOptions.options
        )
      }
    }
  }

  adicionarSaldo() {
    const { getPaymentSettings } = require('../utils/settings')
    const paymentSettings = getPaymentSettings()

    const addCreditsOptions = {
      message: paymentSettings.lara,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuInformacoes',
              },
            ],
          ],
        },
      },
    }

    return addCreditsOptions
  }

  encerramentoDeConta() {
    const tryDisableOptions = {
      message: `<b>Você tem certeza que deseja encerrar sua conta?</b>\n\n<i>Todos os seus dados serão excluidos, não realizamos reembolsos.</i>`,
      options: {
        reply_to_message_id: this.message.message_id,
        parse_mode: 'html',
        chat_id: this.message.message.chat.id,
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: 'ENCERRAR',
                callback_data: 'encerrarConta',
              },
            ],
            [
              {
                text: 'CANCELAR',
                callback_data: 'voltarMenuInformacoes',
              },
            ],
          ],
        },
      },
    }

    return tryDisableOptions
  }

  async encerrarConta() {
    const callbackid = this.message.id
    const { response: userInfo } = await this.Db.user().informacoes()

    const disableOptions = {
      message: String,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
      },
    }

    var deleteUser = await this.Db.user().deletarConta(userInfo.id)

    if (deleteUser.success) {
      disableOptions.message = `<b>Sua conta foi excluida.</b>`
      this.bot.answerCallbackQuery(callbackid, {
        text: 'Conta excluida. Obrigado por usar nossa store!',
        show_alert: true,
      })
    } else {
      console.log(deleteUser.message)
      disableOptions.options.reply_markup = {
        inline_keyboard: [
          [
            {
              text: '🔙 Voltar',
              callback_data: 'voltarMenuInformacoes',
            },
          ],
        ],
      }
      disableOptions.message = 'Tente novamente mais tarde.'
      await this.bot.answerCallbackQuery(
        callbackid,
        'Ocorreu um erro ao excluir sua conta'
      )
    }

    return disableOptions
  }

  async baixarHistorico() {
    const callbackid = this.message.id
    const { response: userInfo } = await this.Db.user().informacoes()
    const getHistoric = await this.Db.user().baixarHistorico()

    if (getHistoric.success) {
      await this.bot.sendChatAction(
        this.message.message.chat.id,
        'upload_document'
      )
      await this.bot.sendDocument(
        this.message.message.chat.id,
        `${__dirname}/../class/user/users/${userInfo.id}.txt`,
        { caption: 'Meu histórico' }
      )
      this.bot.answerCallbackQuery(callbackid, {
        text: 'Download bem sucedido.',
        show_alert: true,
      })

      require('fs').unlink(
        `${__dirname}/../class/user/users/${userInfo.id}.txt`,
        (err) => console.log(err)
      )
    } else {
      //console.log(getHistoric)
      this.bot.answerCallbackQuery(
        callbackid,
        'Ocorreu um erro ao realizar o download de seu histórico.'
      )
    }

    return this.start()
  }

  async listarMix() {
    const callbackid = this.message.id

    const { response: mixList } = await this.Db.mix().listar()

    //console.log(mixList)

    const keyboard = mixList
      .map((mix) => {
        return {
          text: mix.description,
          callback_data: `selecionarMix_${mix.mix_id}`,
        }
      })
      .spliter()

    keyboard.push([
      {
        text: '🔙 Voltar',
        callback_data: 'voltarMenuDeCompra',
      },
    ])

    const mixTable = mixList
      .map((mix) => `- ${mix.description} R$${mix.price}`)
      .join('\n')

    console.log(keyboard)
    //return this.bot.answerCallbackQuery(callbackid, {text: 'Mix indisponível no momento.', alert: false})

    const listMixOptions = {
      message: !mixList.length
        ? `<b>Sem mix disponíveis</b>`
        : `🔀 <b>Mix\n\n${mixTable}</b>`,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: keyboard,
        },
      },
    }

    return listMixOptions
  }

  async selecionarMix(ignoreAny, mixValue) {
    var selectMixOptions = {
      message: String,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    const { response: mixInfo } = await this.Db.mix().mix({
      mix_id: mixValue,
    })

    const ignoreAnyLevels = mixInfo.levels.length > 0 ? true : false
    const filter = mixInfo.levels

    console.log(mixInfo)

    const mix = await this.Db.card().mix(
      ignoreAnyLevels,
      mixInfo.quantity,
      false,
      filter
    )

    if (mix.success) {
      const callbackid = this.message.id

      selectMixOptions.message = `<b>Mix de ${mixInfo.quantity} cartões por R$${mixInfo.price}</b>\n\n⏱ <b>Prazo de troca:</b> <i>${mixInfo.exchange_time}</i>\n☑️ <b> Garantia de live:</b> ${mixInfo.live_percentage}%`

      selectMixOptions.options.reply_markup.inline_keyboard.push(
        [
          {
            text: '❎ Comprar (sem teste)',
            callback_data: `comprarMix_${mixValue}`,
          },
        ],
        [
          {
            text: '✅ Comprar (com teste)',
            callback_data: `comprarMix_${mixValue} testar`,
          },
        ],
        [
          {
            text: '🔙 Voltar',
            callback_data: 'voltarMenuDeMix',
          },
        ]
      )
    } else {
      selectMixOptions.message = mix.response

      selectMixOptions.options.reply_markup.inline_keyboard.push([
        {
          text: '🔙 Voltar',
          callback_data: 'voltarMenuDeMix',
        },
      ])
    }

    this.bot.editMessageText(
      selectMixOptions.message,
      selectMixOptions.options
    )

    return selectMixOptions
  }

  async comprarMix(ignoreAny, mixValue) {
    const { response: mixInfo } = await this.Db.mix().mix({
      mix_id: mixValue.replace(' testar', ''),
    })

    const notificarCompra = async (mixPrice, mixType) => {
      const channelId = process.env.CARDS_SOLD_LOG_CHANNEL
      this.bot.sendMessage(
        channelId,
        `<b>🛒 Compra efetuada (Mix)!</b>\n\n<b>Usuário: </b><code>${userInfo.name
          .split('')
          .shuffle()
          .join('')}</code> - <b>R$${
          userInfo.credits
        } (- R$${mixPrice})</b>\n<b>Id: </b><code>${
          userInfo.id
        }</code>\n\n<b>${mixType} Mix</b>`,
        { parse_mode: 'HTML' }
      )
    }

    const price = mixInfo.price

    const callbackid = this.message.id
    const { response: userInfo } = await this.Db.user().informacoes()

    const Data = require('../utils/PreferenceFunctions')

    var buyMix = {
      message: String,
      options: {
        reply_to_message_id: this.message.message_id,
        chat_id: this.message.message.chat.id,
        parse_mode: 'html',
        message_id: this.message.message.message_id,
        reply_markup: {
          inline_keyboard: [],
        },
      },
    }

    if (userInfo.credits >= price) {
      buyMix.message = `<i>Criando mix...</i>`

      buyMix.options.reply_markup = {
        inline_keyboard: [
          [
            {
              text: '🔄 Verificando',
              callback_data: 'none',
            },
          ],
        ],
      }

      this.bot.editMessageText(buyMix.message, buyMix.options)

      const ignoreAnyLevels = mixInfo.levels.length > 0 ? true : false
      const filter = mixInfo.levels

      const testar = mixValue.includes('testar') ? true : false

      const mix = await this.Db.card().mix(
        ignoreAnyLevels,
        mixInfo.quantity,
        testar,
        filter
      )

      if (mix.success) {
        let updateUser = await this.Db.user().verificarEdeduzirSaldo(
          price,
          mixInfo.quantity
        )

        if (!updateUser.success)
          return this.bot.answerCallbackQuery(callbackid, {
            text: `Saldo insuficiente`,
            show_alert: true,
          })

        const mixString = mix.response
          .map((card) => {
            let Dados = Data.getData()
            return `<b>Cartão:</b> <code>${card.number}|${
              card.month
            }|${card.year}|${card.cvv}</code>\n<b>Banco:</b> <code>${
              card.bin.bank ? card.bin.bank.name : 'Não especificado'
            }</code>\n<b>Nivel: </b><code>${
              card.bin.brand ? card.bin.brand : 'Não especificado'
            }</code>\n<b>Tipo:</b> <code>${
              card.bin.type ? card.bin.type : 'Não especificado'
            }</code>\n<b>Nome: </b><code>${
              Dados.name
            }</code>\n<b>Cpf: </b><code>${Dados.cpf}</code>`
          })
          .join('\n\n')

        buyMix.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n${mixString}`

        for (const card of mix.response) {
          let Dados = Data.getData()
          ;(await this.Db.level().restringirCartao(
            card.number,
            userInfo.id
          )) &&
            (await this.Db.level().anexarDados(card.number, Dados))
        }

        if (mixValue.quantity >= 10) {
          const mixStringTxt = mix.response
            .map((card) => {
              let Dados = Data.getData()
              return `${card.number}|${card.month}|${card.year}|${
                card.cvv
              }||${
                card.bin.bank
                  ? card.bin.bank.name
                  : 'Não especificado'
              }|${
                card.bin.brand ? card.bin.brand : 'Não especificado'
              }|${
                card.bin.type ? card.bin.type : 'Não especificado'
              }|${Dados.name}|${Dados.cpf}`
            })
            .join('\n\n')

          buyMix.message = `✅ <b>Compra efetuada com sucesso.</b>\n\n<i>Sua mix será enviada em formato de arquivo devido ao telegram ter limite de caracteres.</i>`
          const saveMix = await this.Db.card().saveMix(
            mixStringTxt,
            userInfo.id
          )

          if (saveMix.success) {
            await this.bot.sendChatAction(
              this.message.message.chat.id,
              'upload_document'
            )
            await this.bot.sendDocument(
              this.message.message.chat.id,
              `${__dirname}/../class/card/mix/${userInfo.id}.txt`,
              { caption: `Mix de ${mixValue} cartões` }
            )

            require('fs').unlink(
              `${__dirname}/../class/card/mix/${userInfo.id}.txt`,
              (err) => console.log(err)
            )
          } else {
            return this.bot.answerCallbackQuery(callbackid, {
              text: 'Ocorreu um erro ao realizar o envio de sua mix. Baixe seu histórico para recuperá-la e contate-nos.',
              alert: true,
            })
          }
        }

        buyMix.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '❤️',
                callback_data: 'compraFinalizada',
              },
            ],
          ],
        }

        await this.bot.editMessageText(buyMix.message, buyMix.options)

        notificarCompra(mixInfo.price, mixInfo.quantity)
      } else {
        buyMix.message = mix.response

        buyMix.options.reply_markup = {
          inline_keyboard: [
            [
              {
                text: '🔙 Voltar',
                callback_data: 'voltarMenuDeMix',
              },
            ],
          ],
        }

        this.bot.editMessageText(buyMix.message, buyMix.options)
      }
    } else {
      this.bot.answerCallbackQuery(callbackid, {
        text: `Saldo insuficiente`,
        show_alert: true,
      })
    }

    return buyMix
  }
  //
  async compraFinzalizada() {
    return
  }

  async callbackType(data) {
    const isInPurchase = async () => {
      const userInfos = (await this.Db.user().informacoes()).response
      if (userInfos.in_purchase) {
        await this.bot.answerCallbackQuery(this.message.id, {
          show_alert: true,
          text: 'Você so pode comprar uma unitária  por vez.',
        })
        return false
      }
      return true
    }

    const types = {
      comprar: () => this.comprar(),
      informacoes: () => this.informacoes(),
      compras: () => this.compras(),
      niveis: () => this.niveis(),
      full: () => this.niveis(true),
      adicionarSaldo: () => this.adicionarSaldo(),
      deletarConta: () => this.encerramentoDeConta(),
      encerrarConta: () => this.encerrarConta(),
      baixarHistorico: () => this.baixarHistorico(),
      mixDeCartoes: () => this.listarMix(),
      afiliados: () => this.afiliados(),

      //voltar

      voltarMenuInicial: () => this.start(),
      voltarMenuInformacoes: () => this.informacoes(),
      voltarMenuDeCompra: () => this.comprar(),
      voltarMenuNiveis: () => this.niveis(),
      voltarMenuDeMix: () => this.listarMix(),
    }

    if (data.includes('level') && (await isInPurchase()))
      this.enviarCartaoRandomicoOuPorNivel(data.split('_')[1])
    if (data.includes('cartaoAleatorio') && (await isInPurchase()))
      this.enviarCartaoRandomicoOuPorNivel(null, true)
    if (data.includes('comprarCartão') && (await isInPurchase()))
      this.comprarCartao(data.split('_')[1])
    if (data.includes('trocarCartao')) this.trocarCartao(data)
    if (data.includes('mixDeCartoes')) this.listarMix()
    if (data.includes('selecionarMix'))
      this.selecionarMix(true, data.split('_')[1])
    if (data.includes('comprarMix'))
      this.comprarMix(true, data.split('_')[1])
    if (data.includes('compraFinalizada')) this.compraFinzalizada()

    if (!types[data]) return

    const { message, options } = await types[data]()

    this.bot.editMessageText(message, options).catch((err) => err)
  }
}

module.exports = Callback
