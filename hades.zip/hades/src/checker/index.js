'use strict'

const { getConfig } = require('../configManager')
const checkers = require('../services/checkers')

class Checker {
  constructor(db) {
    this.Db = db
  }

  async check(card, restrict = true) {
    try {
      const { currentChecker } = getConfig('checkers')
      const checker = checkers[currentChecker]

      const response = await checker(card)

      if (response.active) {
        let update = await this.Db.Store.findOneAndUpdate(
          { name: process.env.STORE_NAME },
          {
            'alerts.checker': 'Checker disponível',
            'settings.checker': true,
          }
        )

        if (response.live) {
          return {
            success: true,
            card: card,
            live: true,
            message: 'Cartão live',
          }
        } else {
          if (restrict && !response.skip) {
            await this.Db.Cards.findOneAndUpdate(
              { number: card.number },
              { restrict: true, purshased: process.env.STORE_ID },
              { new: true }
            ).populate('level')
          }

          const cardChecked = await this.Db.Cards.findOne({
            number: card.number,
          }).populate('level')

          return {
            success: true,
            card: cardChecked,
            live: false,
            message: 'Cartão die',
          }
        }
      } else {
        let update = await this.Db.Store.findOneAndUpdate(
          { name: process.env.STORE_NAME },
          {
            'alerts.checker':
              'Checagem antes da compra está indisponível.',
            'settings.checker': false,
          }
        )

        return {
          success: false,
          card: card,
          live: false,
          message: 'Checker desativado',
        }
      }
    } catch (e) {
      console.log(e.message)
    }
  }

  async testChecker() {
    const card = {
      number: '6509079001686101',
      month: '11',
      year: '24',
      cvv: '684',
      bin: { type: 'CREDIT' },
    }
    const response = await this.check(card, false)
    return response
  }
}

module.exports = Checker
