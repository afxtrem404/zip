require('../../utils/PrototypeFunctions')

class Mix {
    
    constructor(db, message = {}){
        this.Mix = db.Mix
        this.message = message
    }

   async listar(){
        try {
            const mix = await this.Mix.find({})
            return {
                success: true,
                response: mix
            }

        } catch(e){
            return {
                success: false,
                response: e.message

            }
        }
    }

    async mix(query){
        try {
            const mix = await this.Mix.findOne(query)
            return {
                success: true,
                response: mix
            }

        } catch(e){
            return {
                success: false,
                response: e.message
                
            }
        }
    }
    
}

module.exports = Mix