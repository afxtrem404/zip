class Gift {
    constructor(db){
        this.Gift = db
    }

    async gift(value){

        try {
            var gift = require('uuid').v4().split('-').map(p => {
                if(p.length > 4)
                    return p.substr(0, 4)
                    else return p
            }).join('-')
    
            var newGift = new this.Gift()
                newGift.code = gift
                newGift.redeem = false
                newGift.value = value
                newGift.redeemed = 0

            let g = await newGift.save()

            return {
                success: true,
                message: g
            }

        } catch(e){
            return {
                success: false,
                message: e.message
            }
        }
    }

    async delete(code){
        try {

            const gift = code

            const deleteGift = await this.Gift.deleteOne({code: gift})

            return {
                success: true,
                message: code
            }

        } catch(e){
            return {
                success: false,
                message: e.message
            }
        }
    }

    async resgatado(gift){
        try {
            
            var exists = await this.Gift.exists({code: gift})

            if(!exists){
                return {
                    success: false,
                    message: '<b>Gift não existente.</b>'
                }

            } else {
                var Gift = await this.Gift.findOne({code: gift})

                if(!Gift.redeem){

                    return {
                        success: true,
                        message: '<b>Gift disponível</b>'
                    }

                } else {
                    
                    return {
                        success: false,
                        message: '<b>Gift já resgatado.</b>'
                    }
                }
            }

        } catch(e){
            return {
                success: false,
                message: e.message
            }
        }
    }
}

module.exports = Gift